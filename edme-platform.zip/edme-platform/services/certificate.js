const { PDFDocument, rgb, StandardFonts } = require('pdf-lib');
const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const certsDir = path.join(__dirname, '..', 'certs');
if (!fs.existsSync(certsDir)) fs.mkdirSync(certsDir, { recursive: true });

function makeCertificateCode() {
  return 'EDME-' + uuidv4().split('-')[0].toUpperCase() + '-' + Date.now().toString(36).toUpperCase();
}

// Generates a landscape A4 certificate PDF, saves to disk, returns { code, filePath }
async function generateCertificate({ candidateName, courseTitle, scorePercent, verifyBaseUrl }) {
  const code = makeCertificateCode();
  const verifyUrl = `${verifyBaseUrl}/verify/${code}`;

  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([842, 595]); // A4 landscape
  const { width, height } = page.getSize();

  const navy = rgb(0.06, 0.16, 0.29);
  const accent = rgb(0.06, 0.44, 0.65); // medical blue
  const gray = rgb(0.35, 0.35, 0.35);

  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
  const fontReg = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontItalic = await pdfDoc.embedFont(StandardFonts.HelveticaOblique);

  // Border
  page.drawRectangle({ x: 20, y: 20, width: width - 40, height: height - 40, borderColor: navy, borderWidth: 3 });
  page.drawRectangle({ x: 30, y: 30, width: width - 60, height: height - 60, borderColor: accent, borderWidth: 1 });

  const centerText = (text, y, font, size, color) => {
    const w = font.widthOfTextAtSize(text, size);
    page.drawText(text, { x: (width - w) / 2, y, size, font, color });
  };

  centerText('CERTIFICATE OF COMPLETION', height - 110, fontBold, 26, navy);
  centerText('Emergency Medicine Education (EDME)', height - 140, fontReg, 13, gray);

  centerText('This certifies that', height - 200, fontReg, 14, gray);
  centerText(candidateName, height - 235, fontBold, 30, accent);

  centerText('has successfully completed the self-paced course', height - 275, fontReg, 14, gray);
  centerText(courseTitle, height - 305, fontBold, 20, navy);

  centerText(`with a final examination score of ${scorePercent}%`, height - 340, fontReg, 14, gray);

  const dateStr = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  centerText(dateStr, height - 400, fontReg, 12, gray);

  // Signature line
  page.drawLine({ start: { x: width / 2 - 120, y: 130 }, end: { x: width / 2 + 120, y: 130 }, thickness: 1, color: gray });
  centerText('Dr. Nasser Hassan Abdalrady', 110, fontBold, 13, navy);
  centerText('Emergency Medicine Consultant & Educator', 93, fontItalic, 10, gray);

  // Certificate ID (bottom left)
  page.drawText(`Certificate ID: ${code}`, { x: 50, y: 50, size: 9, font: fontReg, color: gray });

  // QR code (bottom right) linking to verification page
  const qrDataUrl = await QRCode.toDataURL(verifyUrl, { margin: 0, width: 200 });
  const qrImageBytes = Buffer.from(qrDataUrl.split(',')[1], 'base64');
  const qrImage = await pdfDoc.embedPng(qrImageBytes);
  const qrSize = 70;
  page.drawImage(qrImage, { x: width - 50 - qrSize, y: 45, width: qrSize, height: qrSize });
  page.drawText('Scan to verify', { x: width - 50 - qrSize, y: 118, size: 8, font: fontReg, color: gray });

  const pdfBytes = await pdfDoc.save();
  const filePath = path.join(certsDir, `${code}.pdf`);
  fs.writeFileSync(filePath, pdfBytes);

  return { code, filePath, verifyUrl };
}

module.exports = { generateCertificate };
