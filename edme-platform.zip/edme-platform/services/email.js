const nodemailer = require('nodemailer');
const fs = require('fs');

function isConfigured() {
  return Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);
}

function getTransport() {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: Number(process.env.SMTP_PORT) === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
}

// Returns { sent: boolean, reason?: string }
async function sendCertificateEmail({ to, candidateName, courseTitle, scorePercent, pdfPath, certificateCode }) {
  if (!isConfigured()) {
    console.log(`[email] SMTP not configured yet - skipping email to ${to}. Certificate is still available for direct download.`);
    return { sent: false, reason: 'not_configured' };
  }
  try {
    const transport = getTransport();
    const fromAddr = process.env.SMTP_FROM || process.env.SMTP_USER;
    await transport.sendMail({
      from: `"EDME - Emergency Medicine Education" <${fromAddr}>`,
      to,
      subject: `Your Certificate: ${courseTitle}`,
      html: `
        <div style="font-family:Calibri,Arial,sans-serif;max-width:560px;margin:0 auto;">
          <h2 style="color:#0F2A4A;">Congratulations, ${candidateName}!</h2>
          <p>You have successfully passed <strong>${courseTitle}</strong> with a score of <strong>${scorePercent}%</strong>.</p>
          <p>Your certificate of completion is attached to this email.</p>
          <p style="color:#666;font-size:13px;">Certificate ID: ${certificateCode}<br/>
          This certificate can be verified at any time using its unique ID.</p>
          <hr style="border:none;border-top:1px solid #ddd;margin:24px 0;"/>
          <p style="color:#888;font-size:12px;">EDME &mdash; Emergency Medicine Education<br/>
          Dr. Nasser Hassan Abdalrady, Emergency Medicine Consultant &amp; Educator</p>
        </div>`,
      attachments: [
        { filename: `Certificate-${certificateCode}.pdf`, content: fs.readFileSync(pdfPath) }
      ]
    });
    return { sent: true };
  } catch (e) {
    console.error('[email] Failed to send certificate email:', e.message);
    return { sent: false, reason: e.message };
  }
}

module.exports = { sendCertificateEmail, isConfigured };
