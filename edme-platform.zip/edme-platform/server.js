require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');

require('./db'); // initializes DB + seeds admin

const app = express();
app.use(express.json({ limit: '5mb' }));
app.use(cookieParser());

app.use('/api/auth', require('./routes/auth'));
app.use('/api/courses', require('./routes/courses'));
app.use('/api/courses', require('./routes/exams'));
app.use('/api/certificates', require('./routes/certificates'));
app.use('/api/files', require('./routes/files'));
app.use('/api/payments', require('./routes/payments'));
app.use('/api/admin', require('./routes/admin'));

app.use(express.static(path.join(__dirname, 'public')));

app.get('/verify/:code', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'verify.html'));
});

app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found' });
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`EDME platform running on http://localhost:${PORT}`);
  const paypal = require('./services/paypal');
  const email = require('./services/email');
  console.log(`PayPal configured: ${paypal.isConfigured()}`);
  console.log(`Email configured: ${email.isConfigured()}`);
});
