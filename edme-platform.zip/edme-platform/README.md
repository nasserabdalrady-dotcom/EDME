# EDME — Emergency Medicine Education Platform

A self-hosted platform for Dr. Nasser Hassan Abdalrady: self-paced online courses with a
randomized final exam and auto-generated, emailed certificates (80% pass mark), plus a
file marketplace for free or paid clinical resource downloads — paid via PayPal.

## What's included

- **Candidate accounts** — register/login, own dashboard with certificates & purchase history
- **Self-paced courses** — sequential modules, progress tracking, admin-editable content
- **Randomized exam engine** — draws N random questions from your question bank each attempt,
  auto-grades, configurable pass mark (default 80%)
- **Auto-generated certificates** — branded PDF with candidate name, score, date, a unique
  verifiable certificate ID, and a QR code linking to a public verification page
- **Certificate emailing** — sends automatically the moment you add SMTP credentials; works
  fine without them too (candidates just download directly)
- **File marketplace** — upload any file, set price to $0 (free) or any amount (paid via PayPal)
- **PayPal checkout** — for both paid courses and paid file downloads
- **Admin panel** (`/admin.html`) — manage courses, modules, exam questions, files, view
  users/purchases/certificates, see setup status at a glance

This is a real Node.js/Express application with a SQLite database — not a static demo.
Everything above was built and tested end-to-end.

---

## 1. Run it locally first

Requires **Node.js 18+**.

```bash
npm install
cp .env.example .env
```

Open `.env` and set at minimum:
- `JWT_SECRET` — any long random string (the command to generate one is inside the file)
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` — your admin login (created automatically on first run)

Then:

```bash
npm start
```

Visit `http://localhost:3000`. Log in at `/admin.html` with the admin credentials you set,
and start adding courses, modules, exam questions, and files.

**Optional demo content:** `npm run seed` adds one example course ("Airway Management
Fundamentals" — 5 modules, 7 exam questions) so the site isn't empty while you explore.
Delete or edit it from the admin panel any time.

---

## 2. Connect PayPal (you said you have a PayPal Business account)

1. Go to the [PayPal Developer Dashboard](https://developer.paypal.com/dashboard/) and log in
   with your PayPal Business account.
2. Under **Apps & Credentials**, make sure you're on the **Sandbox** tab first (for testing),
   and click **Create App**. Name it anything (e.g. "EDME").
3. Copy the **Client ID** and **Secret** into your `.env`:
   ```
   PAYPAL_CLIENT_ID=...
   PAYPAL_CLIENT_SECRET=...
   PAYPAL_ENV=sandbox
   ```
4. Restart the server. Try buying a paid course or file — PayPal's sandbox lets you pay with
   a fake test buyer account (the Developer Dashboard also has sandbox test accounts under
   **Sandbox > Accounts**).
5. When you're ready to accept real payments: switch to the **Live** tab in the same
   dashboard, create/copy your **live** Client ID and Secret, and update `.env`:
   ```
   PAYPAL_CLIENT_ID=your-live-client-id
   PAYPAL_CLIENT_SECRET=your-live-secret
   PAYPAL_ENV=live
   ```

No code changes needed — just the `.env` values and a restart. The admin panel's
**Setup Status** tab always shows whether PayPal is currently configured.

---

## 3. Connect email later (for auto-sending certificates)

You said you'll add this later — it's fully wired up and ready. Whenever you're ready:

**Easiest option — Gmail:**
1. Turn on 2-Step Verification on the Google account you want to send from.
2. Create an **App Password**: Google Account → Security → 2-Step Verification → App passwords.
3. Add to `.env`:
   ```
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_USER=youraddress@gmail.com
   SMTP_PASS=the-16-character-app-password
   SMTP_FROM=youraddress@gmail.com
   ```

**Or use a transactional email service** (SendGrid, Mailgun, Amazon SES, etc.) — they all
give you an SMTP host/port/user/password that drops into the same four fields.

Restart the server. From that point on, every candidate who passes a final exam gets their
certificate emailed automatically, with zero code changes. Before that, certificates still
generate and are downloadable — nothing is blocked by missing email.

---

## 4. Deploy it live

You need actual hosting for a real backend + database — here are two simple, reliable options.
Either works well for this app's size (SQLite + local file storage).

### Option A — Render.com (recommended, easiest)

1. Push this project to a GitHub repository (private is fine).
2. On [Render](https://render.com), click **New → Web Service**, connect the repo.
3. Settings:
   - **Build command:** `npm install`
   - **Start command:** `npm start`
   - **Instance type:** Free or Starter to begin
4. **Add a persistent disk** (Render dashboard → your service → Disks → Add Disk):
   - Mount path: `/opt/render/project/src/data` — 1GB is plenty to start
   - Add a second disk (or one larger disk with subfolders) for `uploads` and `certs` the
     same way, or simplest: mount one disk at the project root's `/data` and adjust — Render's
     UI will guide you. **This step matters**: without a persistent disk, uploaded files and
     the database reset every time you redeploy.
5. Add all your `.env` values under **Environment** in the dashboard (same keys as `.env.example`).
6. Deploy. Your site is live at the `.onrender.com` URL Render gives you (or attach your own
   domain under Settings → Custom Domain).

### Option B — Railway.app

1. Push to GitHub, then on [Railway](https://railway.app) click **New Project → Deploy from GitHub repo**.
2. Railway auto-detects Node.js and runs `npm install && npm start`.
3. Add a **Volume** (Railway dashboard → your service → Volumes) mounted at `/app/data` (and
   similarly for `uploads`/`certs`) so your database and files persist across deploys.
4. Add your `.env` values under **Variables**.
5. Deploy — Railway gives you a live URL, and you can attach a custom domain under Settings.

### A note on file storage

Uploaded files and certificates are stored on local disk. That's simple and works well at
your current scale — just make sure whichever host you pick has the persistent disk/volume
attached as above. If you ever outgrow it (very large file libraries, multiple servers), the
next step is swapping local disk for S3-compatible storage — the code is structured so that's
a contained change in `services/` rather than a rewrite.

---

## 5. Day-to-day use

- **Admin panel:** `yourdomain.com/admin.html` — add courses, write module content (HTML
  allowed — you can paste in formatted clinical content, images via `<img>` tags, etc.), build
  your exam question bank per course, upload marketplace files and set their price.
- **Public site:** `yourdomain.com` — candidates browse, register, take courses, sit exams,
  and download/receive certificates.
- **Certificate verification:** every certificate's QR code points to
  `yourdomain.com/verify/CERTIFICATE-CODE` — a public page confirming it's genuine, useful if
  an employer wants to check a candidate's certificate.

## Security notes before going live

- Change `ADMIN_PASSWORD` from whatever you tested with, and use a strong `JWT_SECRET`.
- Your host (Render/Railway) provides HTTPS automatically — don't run this over plain HTTP
  in production.
- Back up the `data/edme.sqlite` file periodically (it's your entire database — users,
  courses, purchases, certificates).
- Keep your PayPal secret and SMTP password out of source control — they belong only in
  `.env` / your host's environment variable settings, never committed to Git.

---

*Built for Dr. Nasser Hassan Abdalrady, Emergency Medicine Consultant & Educator.*
