const api = {
  async req(method, url, body) {
    const opts = { method, headers: {}, credentials: 'include' };
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    const res = await fetch(url, opts);
    let data = null;
    try { data = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok) {
      const err = new Error((data && data.error) || `Request failed (${res.status})`);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  },
  get(url) { return this.req('GET', url); },
  post(url, body) { return this.req('POST', url, body || {}); },
  put(url, body) { return this.req('PUT', url, body || {}); },
  del(url) { return this.req('DELETE', url); }
};

async function uploadFile(url, formData) {
  const res = await fetch(url, { method: 'POST', body: formData, credentials: 'include' });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Upload failed');
  return data;
}

function money(cents) {
  if (!cents) return 'Free';
  return '$' + (cents / 100).toFixed(2);
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}

let currentUser = null;
async function loadCurrentUser() {
  try {
    const data = await api.get('/api/auth/me');
    currentUser = data.user;
  } catch (e) {
    currentUser = null;
  }
  return currentUser;
}

function renderNavUser() {
  const el = document.getElementById('navUser');
  if (!el) return;
  if (currentUser) {
    el.innerHTML = `
      <span style="font-size:13px;color:#dfe8f2;">Hi, ${escapeHtml(currentUser.name.split(' ')[0])}</span>
      ${currentUser.role === 'admin' ? '<a href="/admin.html" class="btn btn-outline btn-sm">Admin</a>' : ''}
      <a href="/dashboard.html" class="btn btn-outline btn-sm">Dashboard</a>
      <button class="btn btn-outline btn-sm" onclick="logout()">Log out</button>`;
  } else {
    el.innerHTML = `<button class="btn btn-outline btn-sm" onclick="openAuthModal('login')">Log in</button>
      <button class="btn btn-primary btn-sm" onclick="openAuthModal('register')">Sign up</button>`;
  }
}

async function logout() {
  await api.post('/api/auth/logout');
  window.location.href = '/';
}
