function injectAuthModal() {
  if (document.getElementById('authModalBackdrop')) return;
  const div = document.createElement('div');
  div.innerHTML = `
  <div class="modal-backdrop" id="authModalBackdrop">
    <div class="modal">
      <button class="modal-close" onclick="closeAuthModal()">&times;</button>
      <div class="tab-switch">
        <button id="tabLogin" class="active" onclick="switchAuthTab('login')">Log In</button>
        <button id="tabRegister" onclick="switchAuthTab('register')">Sign Up</button>
      </div>
      <div id="authAlert"></div>

      <form id="loginForm" onsubmit="return handleLogin(event)">
        <div class="form-group">
          <label>Email</label>
          <input type="email" id="loginEmail" required />
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" id="loginPassword" required />
        </div>
        <button class="btn btn-primary btn-block" type="submit">Log In</button>
      </form>

      <form id="registerForm" style="display:none" onsubmit="return handleRegister(event)">
        <div class="form-group">
          <label>Full Name</label>
          <input type="text" id="regName" required />
        </div>
        <div class="form-group">
          <label>Email</label>
          <input type="email" id="regEmail" required />
        </div>
        <div class="form-group">
          <label>Password (min 6 characters)</label>
          <input type="password" id="regPassword" minlength="6" required />
        </div>
        <button class="btn btn-primary btn-block" type="submit">Create Account</button>
      </form>
    </div>
  </div>`;
  document.body.appendChild(div);
}

function openAuthModal(tab) {
  injectAuthModal();
  document.getElementById('authModalBackdrop').classList.add('open');
  switchAuthTab(tab || 'login');
}
function closeAuthModal() {
  const el = document.getElementById('authModalBackdrop');
  if (el) el.classList.remove('open');
}
function switchAuthTab(tab) {
  document.getElementById('authAlert').innerHTML = '';
  document.getElementById('tabLogin').classList.toggle('active', tab === 'login');
  document.getElementById('tabRegister').classList.toggle('active', tab === 'register');
  document.getElementById('loginForm').style.display = tab === 'login' ? 'block' : 'none';
  document.getElementById('registerForm').style.display = tab === 'register' ? 'block' : 'none';
}

async function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  try {
    const data = await api.post('/api/auth/login', { email, password });
    currentUser = data.user;
    closeAuthModal();
    renderNavUser();
    if (typeof onAuthSuccess === 'function') onAuthSuccess();
    else window.location.reload();
  } catch (err) {
    document.getElementById('authAlert').innerHTML = `<div class="alert alert-error">${escapeHtml(err.message)}</div>`;
  }
  return false;
}

async function handleRegister(e) {
  e.preventDefault();
  const name = document.getElementById('regName').value;
  const email = document.getElementById('regEmail').value;
  const password = document.getElementById('regPassword').value;
  try {
    const data = await api.post('/api/auth/register', { name, email, password });
    currentUser = data.user;
    closeAuthModal();
    renderNavUser();
    if (typeof onAuthSuccess === 'function') onAuthSuccess();
    else window.location.reload();
  } catch (err) {
    document.getElementById('authAlert').innerHTML = `<div class="alert alert-error">${escapeHtml(err.message)}</div>`;
  }
  return false;
}

document.addEventListener('DOMContentLoaded', injectAuthModal);
