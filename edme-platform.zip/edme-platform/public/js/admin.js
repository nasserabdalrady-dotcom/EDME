let activeTab = 'courses';
let courseDetailId = null; // when set, courses tab shows module/question management for this course

async function initAdmin() {
  await loadCurrentUser();
  renderNavUser();
  const gate = document.getElementById('gate');
  if (!currentUser || currentUser.role !== 'admin') {
    gate.innerHTML = '<div class="alert alert-error">Admin access required. Please log in with an admin account.</div>';
    openAuthModal('login');
    return;
  }
  gate.style.display = 'none';
  document.getElementById('adminApp').style.display = 'block';
  await loadStats();
  switchTab('courses');
}

async function loadStats() {
  try {
    const s = await api.get('/api/admin/stats');
    document.getElementById('statsRow').innerHTML = `
      <div class="stat-card"><div class="n">${s.userCount}</div><div class="l">Candidates</div></div>
      <div class="stat-card"><div class="n">${s.courseCount}</div><div class="l">Courses</div></div>
      <div class="stat-card"><div class="n">${s.certCount}</div><div class="l">Certificates Issued</div></div>
      <div class="stat-card"><div class="n">${money(s.revenueCents)}</div><div class="l">Revenue (completed)</div></div>
    `;
  } catch (e) { /* ignore */ }
}

function switchTab(tab) {
  activeTab = tab;
  courseDetailId = null;
  document.querySelectorAll('.admin-tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  render();
}

function render() {
  const el = document.getElementById('tabContent');
  if (activeTab === 'courses') return courseDetailId ? renderCourseDetail(el) : renderCourses(el);
  if (activeTab === 'files') return renderFiles(el);
  if (activeTab === 'users') return renderUsers(el);
  if (activeTab === 'purchases') return renderPurchases(el);
  if (activeTab === 'certificates') return renderCertificates(el);
  if (activeTab === 'settings') return renderSettings(el);
}

// ============== COURSES ==============
async function renderCourses(el) {
  el.innerHTML = '<div class="spinner">Loading courses…</div>';
  const { courses } = await api.get('/api/admin/courses');
  el.innerHTML = `
    <div class="panel">
      <h3 style="margin-top:0;">Add New Course</h3>
      <form id="newCourseForm">
        <div class="form-row">
          <div class="form-group"><label>Title</label><input type="text" id="ncTitle" required /></div>
          <div class="form-group"><label>Price (USD, 0 = free)</label><input type="number" id="ncPrice" min="0" step="0.01" value="0" /></div>
        </div>
        <div class="form-group"><label>Description</label><textarea id="ncDesc"></textarea></div>
        <div class="form-row">
          <div class="form-group"><label>Pass mark %</label><input type="number" id="ncPass" min="1" max="100" value="80" /></div>
          <div class="form-group"><label># Exam questions per attempt</label><input type="number" id="ncQCount" min="1" value="10" /></div>
        </div>
        <button class="btn btn-primary" type="submit">Create Course</button>
      </form>
    </div>
    <div class="panel">
      <h3 style="margin-top:0;">All Courses</h3>
      ${courses.length === 0 ? '<div class="empty-state">No courses yet.</div>' : `
      <table class="data-table">
        <thead><tr><th>Title</th><th>Price</th><th>Pass Mark</th><th>Published</th><th>Actions</th></tr></thead>
        <tbody>
          ${courses.map(c => `
            <tr>
              <td>${escapeHtml(c.title)}</td>
              <td>${money(c.price_cents)}</td>
              <td>${c.pass_mark_percent}%</td>
              <td>${c.is_published ? '✓' : '—'}</td>
              <td>
                <button class="btn btn-sm btn-primary" onclick="openCourseDetail(${c.id})">Manage Content</button>
                <button class="btn btn-sm btn-ghost" onclick="togglePublishCourse(${c.id}, ${c.is_published})">${c.is_published ? 'Unpublish' : 'Publish'}</button>
                <button class="btn btn-sm btn-red" onclick="deleteCourse(${c.id})">Delete</button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>`}
    </div>
  `;
  document.getElementById('newCourseForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api.post('/api/admin/courses', {
        title: document.getElementById('ncTitle').value,
        description: document.getElementById('ncDesc').value,
        price_cents: Math.round(parseFloat(document.getElementById('ncPrice').value || 0) * 100),
        pass_mark_percent: parseInt(document.getElementById('ncPass').value || 80),
        exam_question_count: parseInt(document.getElementById('ncQCount').value || 10)
      });
      renderCourses(el);
      loadStats();
    } catch (err) { alert(err.message); }
  });
}

async function togglePublishCourse(id, current) {
  await api.put(`/api/admin/courses/${id}`, { is_published: current ? false : true });
  render();
}
async function deleteCourse(id) {
  if (!confirm('Delete this course and all its modules, questions, and progress? This cannot be undone.')) return;
  await api.del(`/api/admin/courses/${id}`);
  render();
  loadStats();
}

function openCourseDetail(id) {
  courseDetailId = id;
  render();
}

async function renderCourseDetail(el) {
  el.innerHTML = '<div class="spinner">Loading…</div>';
  const [{ courses }, { modules }, { questions }] = await Promise.all([
    api.get('/api/admin/courses'),
    api.get(`/api/admin/courses/${courseDetailId}/modules`),
    api.get(`/api/admin/courses/${courseDetailId}/questions`)
  ]);
  const course = courses.find(c => c.id === courseDetailId);

  el.innerHTML = `
    <button class="btn btn-sm btn-ghost" onclick="switchTab('courses')">&larr; Back to Courses</button>
    <h2 style="color:var(--navy);">${escapeHtml(course.title)}</h2>

    <div class="panel">
      <h3 style="margin-top:0;">Modules (${modules.length})</h3>
      <form id="newModuleForm">
        <div class="form-row">
          <div class="form-group"><label>Title</label><input type="text" id="modTitle" required /></div>
          <div class="form-group"><label>Order</label><input type="number" id="modOrder" value="${modules.length}" /></div>
        </div>
        <div class="form-group"><label>Content (HTML allowed)</label><textarea id="modContent" placeholder="Module content, clinical detail, images (as <img src=...>), etc."></textarea></div>
        <button class="btn btn-primary" type="submit">Add Module</button>
      </form>
      ${modules.length ? `<table class="data-table" style="margin-top:16px;">
        <thead><tr><th>#</th><th>Title</th><th>Actions</th></tr></thead>
        <tbody>${modules.map(m => `
          <tr>
            <td>${m.order_index}</td>
            <td>${escapeHtml(m.title)}</td>
            <td>
              <button class="btn btn-sm btn-ghost" onclick="editModule(${m.id})">Edit</button>
              <button class="btn btn-sm btn-red" onclick="deleteModule(${m.id})">Delete</button>
            </td>
          </tr>`).join('')}</tbody></table>` : ''}
    </div>

    <div class="panel">
      <h3 style="margin-top:0;">Exam Question Bank (${questions.length})</h3>
      <p style="color:var(--gray-600);font-size:13px;">Each attempt randomly draws ${course.exam_question_count} of these questions. Pass mark: ${course.pass_mark_percent}%.</p>
      <form id="newQuestionForm">
        <div class="form-group"><label>Question</label><textarea id="qText" required></textarea></div>
        <div class="form-row">
          <div class="form-group"><label>Option A</label><input type="text" id="qA" required /></div>
          <div class="form-group"><label>Option B</label><input type="text" id="qB" required /></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Option C</label><input type="text" id="qC" required /></div>
          <div class="form-group"><label>Option D</label><input type="text" id="qD" required /></div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Correct Option</label>
            <select id="qCorrect"><option value="a">A</option><option value="b">B</option><option value="c">C</option><option value="d">D</option></select>
          </div>
          <div class="form-group"><label>Explanation (optional)</label><input type="text" id="qExplanation" /></div>
        </div>
        <button class="btn btn-primary" type="submit">Add Question</button>
      </form>
      ${questions.length ? `<table class="data-table" style="margin-top:16px;">
        <thead><tr><th>Question</th><th>Correct</th><th>Actions</th></tr></thead>
        <tbody>${questions.map(q => `
          <tr>
            <td>${escapeHtml(q.question_text.slice(0, 70))}${q.question_text.length > 70 ? '…' : ''}</td>
            <td>${q.correct_option.toUpperCase()}</td>
            <td><button class="btn btn-sm btn-red" onclick="deleteQuestion(${q.id})">Delete</button></td>
          </tr>`).join('')}</tbody></table>` : ''}
    </div>
  `;

  document.getElementById('newModuleForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api.post(`/api/admin/courses/${courseDetailId}/modules`, {
        title: document.getElementById('modTitle').value,
        content: document.getElementById('modContent').value,
        order_index: parseInt(document.getElementById('modOrder').value || 0)
      });
      renderCourseDetail(el);
    } catch (err) { alert(err.message); }
  });

  document.getElementById('newQuestionForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api.post(`/api/admin/courses/${courseDetailId}/questions`, {
        question_text: document.getElementById('qText').value,
        option_a: document.getElementById('qA').value,
        option_b: document.getElementById('qB').value,
        option_c: document.getElementById('qC').value,
        option_d: document.getElementById('qD').value,
        correct_option: document.getElementById('qCorrect').value,
        explanation: document.getElementById('qExplanation').value
      });
      renderCourseDetail(el);
    } catch (err) { alert(err.message); }
  });
}

async function deleteModule(id) {
  if (!confirm('Delete this module?')) return;
  await api.del(`/api/admin/modules/${id}`);
  render();
}
async function deleteQuestion(id) {
  if (!confirm('Delete this question?')) return;
  await api.del(`/api/admin/questions/${id}`);
  render();
}
async function editModule(id) {
  const title = prompt('New title (leave blank to keep current):');
  const content = prompt('New content HTML (leave blank to keep current):');
  const body = {};
  if (title) body.title = title;
  if (content) body.content = content;
  if (Object.keys(body).length === 0) return;
  await api.put(`/api/admin/modules/${id}`, body);
  render();
}

// ============== FILES ==============
async function renderFiles(el) {
  el.innerHTML = '<div class="spinner">Loading files…</div>';
  const { files } = await api.get('/api/admin/files');
  el.innerHTML = `
    <div class="panel">
      <h3 style="margin-top:0;">Upload New File</h3>
      <form id="newFileForm">
        <div class="form-row">
          <div class="form-group"><label>Title</label><input type="text" id="nfTitle" required /></div>
          <div class="form-group"><label>Price (USD, 0 = free)</label><input type="number" id="nfPrice" min="0" step="0.01" value="0" /></div>
        </div>
        <div class="form-group"><label>Description</label><textarea id="nfDesc"></textarea></div>
        <div class="form-group"><label>File</label><input type="file" id="nfFile" required /></div>
        <button class="btn btn-primary" type="submit">Upload</button>
      </form>
    </div>
    <div class="panel">
      <h3 style="margin-top:0;">All Files</h3>
      ${files.length === 0 ? '<div class="empty-state">No files uploaded yet.</div>' : `
      <table class="data-table">
        <thead><tr><th>Title</th><th>Price</th><th>Published</th><th>Actions</th></tr></thead>
        <tbody>
          ${files.map(f => `
            <tr>
              <td>${escapeHtml(f.title)}</td>
              <td>${money(f.price_cents)}</td>
              <td>${f.is_published ? '✓' : '—'}</td>
              <td>
                <button class="btn btn-sm btn-ghost" onclick="togglePublishFile(${f.id}, ${f.is_published})">${f.is_published ? 'Unpublish' : 'Publish'}</button>
                <button class="btn btn-sm btn-red" onclick="deleteFile(${f.id})">Delete</button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>`}
    </div>
  `;
  document.getElementById('newFileForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fileInput = document.getElementById('nfFile');
    if (!fileInput.files[0]) return alert('Please choose a file');
    const fd = new FormData();
    fd.append('title', document.getElementById('nfTitle').value);
    fd.append('description', document.getElementById('nfDesc').value);
    fd.append('price_cents', Math.round(parseFloat(document.getElementById('nfPrice').value || 0) * 100));
    fd.append('file', fileInput.files[0]);
    try {
      await uploadFile('/api/admin/files', fd);
      renderFiles(el);
    } catch (err) { alert(err.message); }
  });
}
async function togglePublishFile(id, current) {
  await api.put(`/api/admin/files/${id}`, { is_published: current ? false : true });
  render();
}
async function deleteFile(id) {
  if (!confirm('Delete this file permanently?')) return;
  await api.del(`/api/admin/files/${id}`);
  render();
}

// ============== USERS / PURCHASES / CERTIFICATES ==============
async function renderUsers(el) {
  el.innerHTML = '<div class="spinner">Loading…</div>';
  const { users } = await api.get('/api/admin/users');
  el.innerHTML = `<div class="panel"><table class="data-table">
    <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th></tr></thead>
    <tbody>${users.map(u => `<tr><td>${escapeHtml(u.name)}</td><td>${escapeHtml(u.email)}</td><td>${u.role}</td><td>${new Date(u.created_at).toLocaleDateString()}</td></tr>`).join('')}</tbody>
  </table></div>`;
}

async function renderPurchases(el) {
  el.innerHTML = '<div class="spinner">Loading…</div>';
  const { purchases } = await api.get('/api/admin/purchases');
  el.innerHTML = `<div class="panel">${purchases.length === 0 ? '<div class="empty-state">No purchases yet.</div>' : `<table class="data-table">
    <thead><tr><th>User</th><th>Type</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
    <tbody>${purchases.map(p => `<tr><td>${escapeHtml(p.user_name)} (${escapeHtml(p.user_email)})</td><td>${p.item_type}</td><td>${money(p.amount_cents)}</td><td>${p.status}</td><td>${new Date(p.created_at).toLocaleDateString()}</td></tr>`).join('')}</tbody>
  </table>`}</div>`;
}

async function renderCertificates(el) {
  el.innerHTML = '<div class="spinner">Loading…</div>';
  const { certificates } = await api.get('/api/admin/certificates');
  el.innerHTML = `<div class="panel">${certificates.length === 0 ? '<div class="empty-state">No certificates issued yet.</div>' : `<table class="data-table">
    <thead><tr><th>Candidate</th><th>Course</th><th>Score</th><th>Emailed</th><th>Issued</th><th></th></tr></thead>
    <tbody>${certificates.map(c => `<tr><td>${escapeHtml(c.user_name)} (${escapeHtml(c.user_email)})</td><td>${escapeHtml(c.course_title)}</td><td>${c.score_percent}%</td><td>${c.email_sent ? '✓' : '—'}</td><td>${new Date(c.issued_at).toLocaleDateString()}</td><td><a class="btn btn-sm btn-primary" href="/api/certificates/${c.id}/download">PDF</a></td></tr>`).join('')}</tbody>
  </table>`}</div>`;
}

async function renderSettings(el) {
  const cfg = await api.get('/api/payments/config');
  el.innerHTML = `
    <div class="panel">
      <h3 style="margin-top:0;">PayPal Payments</h3>
      <p>Status: ${cfg.configured ? '<span class="badge owned">Configured</span>' : '<span class="badge locked">Not configured</span>'}</p>
      <p style="color:var(--gray-600);font-size:13.5px;">Set <code>PAYPAL_CLIENT_ID</code> and <code>PAYPAL_CLIENT_SECRET</code> in your <code>.env</code> file (from your PayPal Business account &rarr; Developer Dashboard &rarr; Apps). Use sandbox keys while testing, then switch <code>PAYPAL_ENV=live</code> with live keys when ready to accept real payments.</p>
    </div>
    <div class="panel">
      <h3 style="margin-top:0;">Certificate Emails</h3>
      <p style="color:var(--gray-600);font-size:13.5px;">Set <code>SMTP_HOST</code>, <code>SMTP_PORT</code>, <code>SMTP_USER</code>, <code>SMTP_PASS</code>, and <code>SMTP_FROM</code> in <code>.env</code>. Once these are set, certificate emails start sending automatically — no code changes needed. Until then, candidates can still download certificates directly after passing.</p>
    </div>
  `;
}

initAdmin();
