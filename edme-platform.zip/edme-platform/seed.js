// Optional: run `npm run seed` once to populate a demo course + free resource
// so the site isn't empty on first visit. Safe to skip - everything here can
// also be created through the Admin Panel.
require('dotenv').config();
const db = require('./db');

const slug = 'airway-management-fundamentals';
const existing = db.prepare('SELECT id FROM courses WHERE slug = ?').get(slug);
if (existing) {
  console.log('Demo course already exists - skipping seed.');
  process.exit(0);
}

const courseInfo = db.prepare(
  `INSERT INTO courses (title, slug, description, price_cents, pass_mark_percent, exam_question_count, is_published)
   VALUES (?, ?, ?, ?, ?, ?, 1)`
).run(
  'Airway Management Fundamentals',
  slug,
  'A self-paced introduction to emergency airway assessment and management, from basic maneuvers through rapid sequence intubation principles.',
  0,
  80,
  5
);
const courseId = courseInfo.lastInsertRowid;

const modules = [
  { title: '1. Airway Assessment', content: '<p>Systematic airway assessment identifies patients at risk of a difficult airway before intervention. Key predictors include limited mouth opening, reduced thyromental distance, restricted neck mobility, and Mallampati class III-IV.</p><p>Always prepare a primary plan and a backup plan before inducing apnea in a patient with a potentially difficult airway.</p>' },
  { title: '2. Basic Airway Maneuvers', content: '<p>Head-tilt/chin-lift and jaw-thrust relieve soft tissue obstruction. Jaw-thrust is preferred when cervical spine injury is suspected.</p><p>Oropharyngeal and nasopharyngeal airways can maintain patency in obtunded patients but are not substitutes for definitive airway control when indicated.</p>' },
  { title: '3. Bag-Valve-Mask Ventilation', content: '<p>Effective BVM ventilation relies on a proper mask seal, correct head positioning, and avoidance of excessive tidal volumes, which risk gastric insufflation and aspiration.</p><p>A two-person technique with one provider maintaining the seal and one squeezing the bag improves ventilation quality in difficult cases.</p>' },
  { title: '4. Rapid Sequence Intubation (RSI) Principles', content: '<p>RSI combines a potent induction agent with a rapid-onset neuromuscular blocker to achieve optimal intubating conditions while minimizing aspiration risk.</p><p>Preoxygenation, preparation of equipment and backup plans, and confirmation of tube placement with waveform capnography are essential steps.</p>' },
  { title: '5. Failed Airway Algorithm', content: '<p>A failed airway requires immediate escalation: optimize positioning, attempt an alternate device (e.g. supraglottic airway), and be prepared to proceed to a surgical airway if oxygenation cannot be achieved.</p><p>Cognitive aids and a pre-declared "call for help" trigger reduce delays during a crisis.</p>' }
];
const insertModule = db.prepare('INSERT INTO modules (course_id, title, content, order_index) VALUES (?, ?, ?, ?)');
modules.forEach((m, i) => insertModule.run(courseId, m.title, m.content, i));

const questions = [
  ['Which physical exam finding is most associated with a difficult airway?', 'Normal mouth opening', 'Mallampati class III-IV', 'Full neck range of motion', 'Thyromental distance > 6.5cm', 'b', 'Higher Mallampati class correlates with reduced visualization of the glottis.'],
  ['Which airway maneuver is preferred when cervical spine injury is suspected?', 'Head-tilt/chin-lift', 'Sniffing position', 'Jaw-thrust', 'Hyperextension', 'c', 'Jaw-thrust opens the airway without extending the cervical spine.'],
  ['A common risk of excessive tidal volume during BVM ventilation is:', 'Bradycardia', 'Gastric insufflation and aspiration risk', 'Improved oxygenation', 'Reduced airway resistance', 'b', 'High-volume, high-pressure ventilation pushes air into the stomach as well as the lungs.'],
  ['What is the primary goal of preoxygenation before RSI?', 'Sedate the patient', 'Extend the safe apnea time', 'Reduce heart rate', 'Numb the airway', 'b', 'Preoxygenation builds an oxygen reserve, extending the time before desaturation during apnea.'],
  ['In a failed airway with inability to oxygenate, the next step is typically:', 'Repeat the same technique', 'Wait and reassess in 10 minutes', 'Attempt an alternate device or proceed toward a surgical airway', 'Discharge the patient', 'c', 'A "cannot oxygenate" scenario requires immediate escalation per the failed airway algorithm.'],
  ['Which confirms correct endotracheal tube placement most reliably?', 'Chest auscultation alone', 'Waveform capnography', 'Visualizing the tube pass the cords only', 'Pulse oximetry alone', 'b', 'Continuous waveform capnography is the gold-standard confirmation method.'],
  ['A jaw-thrust with no adjuncts is an example of:', 'A definitive airway', 'A basic airway maneuver', 'A surgical airway', 'RSI', 'b', 'Definitive airways involve a cuffed tube in the trachea; jaw-thrust is a basic maneuver.']
];
const insertQ = db.prepare(
  `INSERT INTO questions (course_id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
);
questions.forEach(q => insertQ.run(courseId, q[0], q[1], q[2], q[3], q[4], q[5], q[6]));

console.log(`Seeded demo course "Airway Management Fundamentals" (id=${courseId}) with ${modules.length} modules and ${questions.length} exam questions.`);
console.log('You can edit or delete this at any time from the Admin Panel.');
