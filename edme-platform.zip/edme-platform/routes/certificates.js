const express = require('express');
const fs = require('fs');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// My certificates
router.get('/', requireAuth, (req, res) => {
  const certs = db.prepare(
    `SELECT c.id, c.certificate_code, c.score_percent, c.email_sent, c.issued_at, co.title AS course_title
     FROM certificates c JOIN courses co ON co.id = c.course_id
     WHERE c.user_id = ? ORDER BY c.issued_at DESC`
  ).all(req.user.id);
  res.json({ certificates: certs });
});

// Download my certificate PDF
router.get('/:id/download', requireAuth, (req, res) => {
  const cert = db.prepare('SELECT * FROM certificates WHERE id = ?').get(req.params.id);
  if (!cert) return res.status(404).json({ error: 'Certificate not found' });
  if (cert.user_id !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Not authorized' });
  }
  if (!fs.existsSync(cert.pdf_path)) return res.status(410).json({ error: 'Certificate file missing' });
  res.download(cert.pdf_path, `Certificate-${cert.certificate_code}.pdf`);
});

// Public verification (no auth) - used by the QR code on the certificate
router.get('/verify/:code', (req, res) => {
  const cert = db.prepare(
    `SELECT c.certificate_code, c.score_percent, c.issued_at, u.name AS candidate_name, co.title AS course_title
     FROM certificates c
     JOIN users u ON u.id = c.user_id
     JOIN courses co ON co.id = c.course_id
     WHERE c.certificate_code = ?`
  ).get(req.params.code);

  if (!cert) return res.status(404).json({ valid: false, error: 'Certificate not found' });
  res.json({ valid: true, certificate: cert });
});

module.exports = router;
