const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');
const { hasCourseAccess } = require('./courses');
const { generateCertificate } = require('../services/certificate');
const { sendCertificateEmail } = require('../services/email');

const router = express.Router();

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Get a randomized exam paper (correct answers withheld)
router.get('/:courseId/exam', requireAuth, (req, res) => {
  const course = db.prepare('SELECT * FROM courses WHERE id = ?').get(req.params.courseId);
  if (!course) return res.status(404).json({ error: 'Course not found' });
  if (!hasCourseAccess(req.user.id, course)) return res.status(403).json({ error: 'Purchase required to take the exam' });

  const allQuestions = db.prepare('SELECT * FROM questions WHERE course_id = ?').all(course.id);
  if (allQuestions.length === 0) return res.status(400).json({ error: 'This course has no exam questions yet' });

  const count = Math.min(course.exam_question_count, allQuestions.length);
  const selected = shuffle(allQuestions).slice(0, count);

  const paper = selected.map(q => ({
    id: q.id,
    question_text: q.question_text,
    options: { a: q.option_a, b: q.option_b, c: q.option_c, d: q.option_d }
  }));

  res.json({
    course_id: course.id,
    pass_mark_percent: course.pass_mark_percent,
    questions: paper
  });
});

// Submit exam answers -> auto-grade -> issue certificate if passed
router.post('/:courseId/exam/submit', requireAuth, async (req, res) => {
  const course = db.prepare('SELECT * FROM courses WHERE id = ?').get(req.params.courseId);
  if (!course) return res.status(404).json({ error: 'Course not found' });
  if (!hasCourseAccess(req.user.id, course)) return res.status(403).json({ error: 'Purchase required' });

  const { answers } = req.body; // { [questionId]: 'a'|'b'|'c'|'d' }
  if (!answers || typeof answers !== 'object' || Object.keys(answers).length === 0) {
    return res.status(400).json({ error: 'No answers submitted' });
  }

  const questionIds = Object.keys(answers).map(Number);
  const placeholders = questionIds.map(() => '?').join(',');
  const questions = db.prepare(`SELECT * FROM questions WHERE id IN (${placeholders}) AND course_id = ?`)
    .all(...questionIds, course.id);

  let correctCount = 0;
  const review = [];
  for (const q of questions) {
    const given = (answers[q.id] || '').toLowerCase();
    const isCorrect = given === q.correct_option.toLowerCase();
    if (isCorrect) correctCount++;
    review.push({
      question_id: q.id,
      question_text: q.question_text,
      given_answer: given || null,
      correct_answer: q.correct_option,
      is_correct: isCorrect,
      explanation: q.explanation
    });
  }

  const total = questions.length;
  const scorePercent = total > 0 ? Math.round((correctCount / total) * 100) : 0;
  const passed = scorePercent >= course.pass_mark_percent;

  const attemptInfo = db.prepare(
    `INSERT INTO exam_attempts (user_id, course_id, score_percent, passed, total_questions, correct_count, answers_json)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(req.user.id, course.id, scorePercent, passed ? 1 : 0, total, correctCount, JSON.stringify(answers));

  let certificate = null;
  if (passed) {
    const verifyBaseUrl = `${req.protocol}://${req.get('host')}`;
    const { code, filePath } = await generateCertificate({
      candidateName: req.user.name,
      courseTitle: course.title,
      scorePercent,
      verifyBaseUrl
    });

    const certInfo = db.prepare(
      `INSERT INTO certificates (user_id, course_id, exam_attempt_id, certificate_code, score_percent, pdf_path)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(req.user.id, course.id, attemptInfo.lastInsertRowid, code, scorePercent, filePath);

    const emailResult = await sendCertificateEmail({
      to: req.user.email,
      candidateName: req.user.name,
      courseTitle: course.title,
      scorePercent,
      pdfPath: filePath,
      certificateCode: code
    });
    if (emailResult.sent) {
      db.prepare('UPDATE certificates SET email_sent = 1 WHERE id = ?').run(certInfo.lastInsertRowid);
    }

    certificate = {
      id: certInfo.lastInsertRowid,
      code,
      score_percent: scorePercent,
      email_sent: emailResult.sent,
      email_reason: emailResult.reason || null,
      download_url: `/api/certificates/${certInfo.lastInsertRowid}/download`
    };
  }

  res.json({
    score_percent: scorePercent,
    correct_count: correctCount,
    total_questions: total,
    passed,
    pass_mark_percent: course.pass_mark_percent,
    review,
    certificate
  });
});

// Past attempts for the logged-in user
router.get('/:courseId/attempts', requireAuth, (req, res) => {
  const attempts = db.prepare(
    'SELECT id, score_percent, passed, total_questions, correct_count, created_at FROM exam_attempts WHERE user_id = ? AND course_id = ? ORDER BY created_at DESC'
  ).all(req.user.id, req.params.courseId);
  res.json({ attempts });
});

module.exports = router;
