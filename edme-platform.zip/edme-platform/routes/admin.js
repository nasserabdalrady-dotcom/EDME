const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth, requireAdmin);

const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const safe = Date.now() + '-' + file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, '_');
    cb(null, safe);
  }
});
const upload = multer({ storage, limits: { fileSize: 200 * 1024 * 1024 } }); // 200MB cap

function slugify(str) {
  return str.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
}

// ---------- Courses ----------
router.get('/courses', (req, res) => {
  const courses = db.prepare('SELECT * FROM courses ORDER BY created_at DESC').all();
  res.json({ courses });
});

router.post('/courses', (req, res) => {
  const { title, description, price_cents, pass_mark_percent, exam_question_count, is_published } = req.body;
  if (!title) return res.status(400).json({ error: 'Title is required' });
  let slug = slugify(title);
  const exists = db.prepare('SELECT id FROM courses WHERE slug = ?').get(slug);
  if (exists) slug = slug + '-' + Date.now().toString(36);

  const info = db.prepare(
    `INSERT INTO courses (title, slug, description, price_cents, pass_mark_percent, exam_question_count, is_published)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(title, slug, description || '', price_cents || 0, pass_mark_percent || 80, exam_question_count || 10, is_published === false ? 0 : 1);

  res.json({ course: db.prepare('SELECT * FROM courses WHERE id = ?').get(info.lastInsertRowid) });
});

router.put('/courses/:id', (req, res) => {
  const c = db.prepare('SELECT * FROM courses WHERE id = ?').get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Course not found' });
  const { title, description, price_cents, pass_mark_percent, exam_question_count, is_published } = req.body;
  db.prepare(
    `UPDATE courses SET title=?, description=?, price_cents=?, pass_mark_percent=?, exam_question_count=?, is_published=? WHERE id=?`
  ).run(
    title ?? c.title, description ?? c.description, price_cents ?? c.price_cents,
    pass_mark_percent ?? c.pass_mark_percent, exam_question_count ?? c.exam_question_count,
    is_published === undefined ? c.is_published : (is_published ? 1 : 0), c.id
  );
  res.json({ course: db.prepare('SELECT * FROM courses WHERE id = ?').get(c.id) });
});

router.delete('/courses/:id', (req, res) => {
  db.prepare('DELETE FROM courses WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- Modules ----------
router.get('/courses/:courseId/modules', (req, res) => {
  const modules = db.prepare('SELECT * FROM modules WHERE course_id = ? ORDER BY order_index ASC').all(req.params.courseId);
  res.json({ modules });
});

router.post('/courses/:courseId/modules', (req, res) => {
  const { title, content, order_index } = req.body;
  if (!title) return res.status(400).json({ error: 'Title is required' });
  const info = db.prepare('INSERT INTO modules (course_id, title, content, order_index) VALUES (?, ?, ?, ?)')
    .run(req.params.courseId, title, content || '', order_index || 0);
  res.json({ module: db.prepare('SELECT * FROM modules WHERE id = ?').get(info.lastInsertRowid) });
});

router.put('/modules/:id', (req, res) => {
  const m = db.prepare('SELECT * FROM modules WHERE id = ?').get(req.params.id);
  if (!m) return res.status(404).json({ error: 'Module not found' });
  const { title, content, order_index } = req.body;
  db.prepare('UPDATE modules SET title=?, content=?, order_index=? WHERE id=?')
    .run(title ?? m.title, content ?? m.content, order_index ?? m.order_index, m.id);
  res.json({ module: db.prepare('SELECT * FROM modules WHERE id = ?').get(m.id) });
});

router.delete('/modules/:id', (req, res) => {
  db.prepare('DELETE FROM modules WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- Exam Questions ----------
router.get('/courses/:courseId/questions', (req, res) => {
  const questions = db.prepare('SELECT * FROM questions WHERE course_id = ? ORDER BY id ASC').all(req.params.courseId);
  res.json({ questions });
});

router.post('/courses/:courseId/questions', (req, res) => {
  const { question_text, option_a, option_b, option_c, option_d, correct_option, explanation } = req.body;
  if (!question_text || !option_a || !option_b || !option_c || !option_d || !correct_option) {
    return res.status(400).json({ error: 'question_text, four options and correct_option are required' });
  }
  if (!['a', 'b', 'c', 'd'].includes(correct_option.toLowerCase())) {
    return res.status(400).json({ error: 'correct_option must be a, b, c or d' });
  }
  const info = db.prepare(
    `INSERT INTO questions (course_id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(req.params.courseId, question_text, option_a, option_b, option_c, option_d, correct_option.toLowerCase(), explanation || '');
  res.json({ question: db.prepare('SELECT * FROM questions WHERE id = ?').get(info.lastInsertRowid) });
});

router.put('/questions/:id', (req, res) => {
  const q = db.prepare('SELECT * FROM questions WHERE id = ?').get(req.params.id);
  if (!q) return res.status(404).json({ error: 'Question not found' });
  const { question_text, option_a, option_b, option_c, option_d, correct_option, explanation } = req.body;
  db.prepare(
    `UPDATE questions SET question_text=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=?, explanation=? WHERE id=?`
  ).run(
    question_text ?? q.question_text, option_a ?? q.option_a, option_b ?? q.option_b, option_c ?? q.option_c,
    option_d ?? q.option_d, (correct_option ?? q.correct_option).toLowerCase(), explanation ?? q.explanation, q.id
  );
  res.json({ question: db.prepare('SELECT * FROM questions WHERE id = ?').get(q.id) });
});

router.delete('/questions/:id', (req, res) => {
  db.prepare('DELETE FROM questions WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- Marketplace Files ----------
router.get('/files', (req, res) => {
  const files = db.prepare('SELECT * FROM files ORDER BY created_at DESC').all();
  res.json({ files });
});

router.post('/files', upload.single('file'), (req, res) => {
  const { title, description, price_cents } = req.body;
  if (!title || !req.file) return res.status(400).json({ error: 'Title and a file are required' });
  const info = db.prepare(
    'INSERT INTO files (title, description, price_cents, file_path, original_name) VALUES (?, ?, ?, ?, ?)'
  ).run(title, description || '', Number(price_cents) || 0, req.file.path, req.file.originalname);
  res.json({ file: db.prepare('SELECT * FROM files WHERE id = ?').get(info.lastInsertRowid) });
});

router.put('/files/:id', (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id = ?').get(req.params.id);
  if (!f) return res.status(404).json({ error: 'File not found' });
  const { title, description, price_cents, is_published } = req.body;
  db.prepare('UPDATE files SET title=?, description=?, price_cents=?, is_published=? WHERE id=?')
    .run(title ?? f.title, description ?? f.description, price_cents ?? f.price_cents,
      is_published === undefined ? f.is_published : (is_published ? 1 : 0), f.id);
  res.json({ file: db.prepare('SELECT * FROM files WHERE id = ?').get(f.id) });
});

router.delete('/files/:id', (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id = ?').get(req.params.id);
  if (f && fs.existsSync(f.file_path)) fs.unlinkSync(f.file_path);
  db.prepare('DELETE FROM files WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- Users / Purchases / Certificates (read-only views) ----------
router.get('/users', (req, res) => {
  const users = db.prepare('SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC').all();
  res.json({ users });
});

router.get('/purchases', (req, res) => {
  const purchases = db.prepare(
    `SELECT p.*, u.name AS user_name, u.email AS user_email FROM purchases p
     JOIN users u ON u.id = p.user_id ORDER BY p.created_at DESC`
  ).all();
  res.json({ purchases });
});

router.get('/certificates', (req, res) => {
  const certs = db.prepare(
    `SELECT c.*, u.name AS user_name, u.email AS user_email, co.title AS course_title
     FROM certificates c JOIN users u ON u.id = c.user_id JOIN courses co ON co.id = c.course_id
     ORDER BY c.issued_at DESC`
  ).all();
  res.json({ certificates: certs });
});

router.get('/stats', (req, res) => {
  const userCount = db.prepare("SELECT COUNT(*) AS n FROM users WHERE role='candidate'").get().n;
  const courseCount = db.prepare('SELECT COUNT(*) AS n FROM courses').get().n;
  const certCount = db.prepare('SELECT COUNT(*) AS n FROM certificates').get().n;
  const revenueCents = db.prepare("SELECT COALESCE(SUM(amount_cents),0) AS n FROM purchases WHERE status='completed'").get().n;
  res.json({ userCount, courseCount, certCount, revenueCents });
});

module.exports = router;
