const express = require('express');
const fs = require('fs');
const db = require('../db');
const { requireAuth, optionalAuth } = require('../middleware/auth');

const router = express.Router();

function hasFileAccess(userId, file) {
  if (file.price_cents === 0) return true;
  const purchase = db.prepare(
    `SELECT id FROM purchases WHERE user_id = ? AND item_type = 'file' AND item_id = ? AND status = 'completed'`
  ).get(userId, file.id);
  return Boolean(purchase);
}

// Public: list published files
router.get('/', optionalAuth, (req, res) => {
  const files = db.prepare('SELECT id, title, description, price_cents, original_name, created_at FROM files WHERE is_published = 1 ORDER BY created_at DESC').all();
  const withAccess = files.map(f => ({
    ...f,
    has_access: req.user ? hasFileAccess(req.user.id, f) : f.price_cents === 0
  }));
  res.json({ files: withAccess });
});

// Download a file (free = instant, paid = requires completed purchase)
router.get('/:id/download', requireAuth, (req, res) => {
  const file = db.prepare('SELECT * FROM files WHERE id = ? AND is_published = 1').get(req.params.id);
  if (!file) return res.status(404).json({ error: 'File not found' });
  if (!hasFileAccess(req.user.id, file)) return res.status(403).json({ error: 'Purchase required' });
  if (!fs.existsSync(file.file_path)) return res.status(410).json({ error: 'File missing on server' });
  res.download(file.file_path, file.original_name || file.title);
});

router.hasFileAccess = hasFileAccess;
module.exports = router;
