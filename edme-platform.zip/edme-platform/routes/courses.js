const express = require('express');
const db = require('../db');
const { requireAuth, optionalAuth } = require('../middleware/auth');

const router = express.Router();

function hasCourseAccess(userId, course) {
  if (course.price_cents === 0) return true;
  const purchase = db.prepare(
    `SELECT id FROM purchases WHERE user_id = ? AND item_type = 'course' AND item_id = ? AND status = 'completed'`
  ).get(userId, course.id);
  return Boolean(purchase);
}

// Public: list published courses
router.get('/', optionalAuth, (req, res) => {
  const courses = db.prepare('SELECT * FROM courses WHERE is_published = 1 ORDER BY created_at DESC').all();
  const withAccess = courses.map(c => ({
    ...c,
    has_access: req.user ? hasCourseAccess(req.user.id, c) : c.price_cents === 0
  }));
  res.json({ courses: withAccess });
});

// Get one course - modules only included if user has access
router.get('/:slug', optionalAuth, (req, res) => {
  const course = db.prepare('SELECT * FROM courses WHERE slug = ? AND is_published = 1').get(req.params.slug);
  if (!course) return res.status(404).json({ error: 'Course not found' });

  const access = req.user ? hasCourseAccess(req.user.id, course) : course.price_cents === 0;
  let modules = [];
  let completedModuleIds = [];
  if (access) {
    modules = db.prepare('SELECT id, title, content, order_index FROM modules WHERE course_id = ? ORDER BY order_index ASC').all(course.id);
    if (req.user) {
      completedModuleIds = db.prepare('SELECT module_id FROM progress WHERE user_id = ? AND course_id = ?')
        .all(req.user.id, course.id).map(r => r.module_id);
    }
  } else {
    // Still show module titles as a locked preview
    modules = db.prepare('SELECT id, title, order_index FROM modules WHERE course_id = ? ORDER BY order_index ASC').all(course.id)
      .map(m => ({ id: m.id, title: m.title, order_index: m.order_index, locked: true }));
  }

  res.json({ course, modules, has_access: access, completed_module_ids: completedModuleIds });
});

// Mark a module complete (requires access)
router.post('/:courseId/modules/:moduleId/complete', requireAuth, (req, res) => {
  const course = db.prepare('SELECT * FROM courses WHERE id = ?').get(req.params.courseId);
  if (!course) return res.status(404).json({ error: 'Course not found' });
  if (!hasCourseAccess(req.user.id, course)) return res.status(403).json({ error: 'Purchase required' });

  const moduleRow = db.prepare('SELECT id FROM modules WHERE id = ? AND course_id = ?').get(req.params.moduleId, course.id);
  if (!moduleRow) return res.status(404).json({ error: 'Module not found' });

  db.prepare('INSERT OR IGNORE INTO progress (user_id, course_id, module_id) VALUES (?, ?, ?)')
    .run(req.user.id, course.id, moduleRow.id);

  res.json({ ok: true });
});

router.hasCourseAccess = hasCourseAccess;
module.exports = router;
