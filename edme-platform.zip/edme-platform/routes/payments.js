const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');
const paypal = require('../services/paypal');

const router = express.Router();

function getItem(itemType, itemId) {
  if (itemType === 'course') {
    return db.prepare('SELECT * FROM courses WHERE id = ? AND is_published = 1').get(itemId);
  }
  if (itemType === 'file') {
    return db.prepare('SELECT * FROM files WHERE id = ? AND is_published = 1').get(itemId);
  }
  return null;
}

router.get('/config', (req, res) => {
  res.json({
    configured: paypal.isConfigured(),
    client_id: process.env.PAYPAL_CLIENT_ID || null
  });
});

// Create a PayPal order for a course or file
router.post('/create-order', requireAuth, async (req, res) => {
  try {
    const { item_type, item_id } = req.body;
    if (!['course', 'file'].includes(item_type)) return res.status(400).json({ error: 'Invalid item_type' });

    const item = getItem(item_type, item_id);
    if (!item) return res.status(404).json({ error: 'Item not found' });
    if (item.price_cents <= 0) return res.status(400).json({ error: 'This item is free - no payment needed' });

    const amountUsd = item.price_cents / 100;
    const purchaseInfo = db.prepare(
      `INSERT INTO purchases (user_id, item_type, item_id, amount_cents, status) VALUES (?, ?, ?, ?, 'pending')`
    ).run(req.user.id, item_type, item.id, item.price_cents);

    const order = await paypal.createOrder({
      amountUsd,
      description: item.title,
      referenceId: String(purchaseInfo.lastInsertRowid)
    });

    db.prepare('UPDATE purchases SET paypal_order_id = ? WHERE id = ?').run(order.id, purchaseInfo.lastInsertRowid);

    res.json({ order_id: order.id, purchase_id: purchaseInfo.lastInsertRowid });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

// Capture payment after buyer approves on PayPal
router.post('/capture-order', requireAuth, async (req, res) => {
  try {
    const { order_id } = req.body;
    if (!order_id) return res.status(400).json({ error: 'order_id is required' });

    const purchase = db.prepare('SELECT * FROM purchases WHERE paypal_order_id = ? AND user_id = ?').get(order_id, req.user.id);
    if (!purchase) return res.status(404).json({ error: 'Purchase not found' });

    const capture = await paypal.captureOrder(order_id);
    const status = capture.status === 'COMPLETED' ? 'completed' : 'failed';

    db.prepare('UPDATE purchases SET status = ? WHERE id = ?').run(status, purchase.id);

    res.json({ status, purchase_id: purchase.id, item_type: purchase.item_type, item_id: purchase.item_id });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

// My purchase history
router.get('/my-purchases', requireAuth, (req, res) => {
  const purchases = db.prepare('SELECT * FROM purchases WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
  res.json({ purchases });
});

module.exports = router;
